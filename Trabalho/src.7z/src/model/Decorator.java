/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javax.swing.Icon;


/**
 *
 * @author Jéssica Petersen
 */
public interface Decorator {
    
    Icon getImagem();
    
    void setImagem(Icon imagem);
    
}
